
import React from 'react'
import Masonry, { ResponsiveMasonry } from "react-responsive-masonry"


function ChoosebyTheme() {
    return (
        <>

            <div className='container-wrapper'>
                <p className='text-2xl text-center font-bold capitalize'>Choose by <span className='text-red-500'>theme</span></p>
                <ResponsiveMasonry columnsCountBreakPoints={{ 350: 2, 750: 2, 900: 4 }} >
                    <Masonry gutter={"10px"}>
                    <img className='w-full h-full object-cover' src="assets/images/grid1.png" alt="" />
                    <img className='w-full h-full object-cover' src="assets/images/grid4.png" alt="" />
                    <img className='w-full h-full object-cover' src="assets/images/grid2.png" alt="" />
                    <img className='w-full h-full object-cover' src="assets/images/grid5.png" alt="" />
                    <img className='w-full h-full object-cover' src="assets/images/grid3.png" alt="" />
                    <img className='w-full h-full object-cover' src="assets/images/grid6.png" alt="" />


                       
                    </Masonry>
                </ResponsiveMasonry>
                <div className='grid grid-cols-2 sm:grid-col-2 md:grid-col-3 lg:grid-cols-3 xl:grid-cols-3 grou grid-row-4   container-wrapper gap-3'>


                </div>
            </div>

        </>
    )
}

export default ChoosebyTheme