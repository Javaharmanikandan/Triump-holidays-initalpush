import React from 'react'
import { useNavigate } from 'react-router'

function HeaderSection() {
    const navigate = useNavigate();
    return (
        <>
            <div className=" w-full bg-green-200 relative p-5  pb-48">
                <img className="absolute inset-0 h-full w-full object-cover" src="assets/images/bnr-img.png" alt="" />
                <div className="hidden sm:flex md:flex lg:flex xl:flex  z-10 relative  md:float-right lg:float-right xl:float-right gap-x-2 px-20">
                    <div className='flex flex-col w-fit cursor-pointer group'>
                        <p className="text-white">Domestic packages</p>
                        <div className='h-1 w-full group-hover:bg-red-600 rounded-full'></div>
                    </div>
                    <div className='flex flex-col w-fit cursor-pointer group'>
                        <p className="text-white">International packages</p>
                        <div className='h-1 w-full group-hover:bg-red-600 rounded-full'></div>
                    </div>
                    <img className='w-5' src="assets/images/svg/glob.svg" alt="" />
                    <img className='w-5' src="assets/images/svg/circle-user.svg" alt="" />
                </div>

                <div className="relative flex justify-center w-full mt-24 ">
                    <p className="text-5xl font-Gloom text-center font-bold capitalize text-white">Ticket to dream <br /> destination</p>
                </div>

                <div className="relative mt-16 hidden md:flex lg:flex xl:flex flex-row md:flex-row lg:flex-row xl:flex-row justify-center w-full gap-x-16  items-stretch">
                    <div className="relative z-10 gap-y-5 flex flex-col md:flex-col lg:flex-row xl:flex-row gap-x-3 p-5 bg-white w-fit after:rounded-md  md:after:w-[0%] lg:after:w-[107%] xl:after:2-[107%] after:content-[''] after:bg-white after:w-[0%] after:h-full after:absolute  after:skew-y-[0deg] after:skew-x-[340deg] after:z-[-1] after:top-0 after:-left-6 after:zindex-[-5px]" >
                        <div className="flex gap-x-2 items-center border border-black/20 p-3 rounded-[5px]">
                            <img className="h-10" src="assets/images/svg/map.svg" alt="" />
                            <p className="capitalize text-sm">destination</p>
                            <img className="h-2" src="assets/images/svg/down-arrow.svg" alt="" />
                        </div>
                        <div className="flex gap-x-2 items-center border border-black/20 p-3 rounded-[5px]">
                            <img className="h-10" src="assets/images/svg/map.svg" alt="" />
                            <p className="capitalize text-sm">destination</p>
                            <img className="h-2" src="assets/images/svg/down-arrow.svg" alt="" />

                        </div> <div className="flex gap-x-2 items-center border border-black/20 p-3 rounded-[5px]">
                            <img className="h-10" src="assets/images/svg/map.svg" alt="" />
                            <p className="capitalize text-sm">destination</p>
                            <img className="h-2" src="assets/images/svg/down-arrow.svg" alt="" />

                        </div> <div className="flex gap-x-2 items-center border border-black/20 p-3 rounded-[5px]">
                            <img className="h-10" src="assets/images/svg/map.svg" alt="" />
                            <p className="capitalize text-sm">destination</p>
                            <img className="h-2" src="assets/images/svg/down-arrow.svg" alt="" />

                        </div>
                    </div>
                    <div onClick={()=>{navigate('/search')}} className="h-50 cursor-pointer w-fit p-2 px-5 bg-red-500 flex justify-center items-center " style={{clipPath: "polygon(15% 0, 0 100%, 68% 100%, 100% 49%, 74% 0)"}}>
                        <p className="text-white">Go</p>
                    </div>

                </div>
            </div>
        </>
    )
}

export default HeaderSection