import React from 'react'

function DetailCard() {
    return (
        <>
            <div className='shadow-lg p-5 my-5 rounded-lg  flex-col items-center gap-5 MobileHide-DesktopView-flex'>
                <div className='flex justify-between gap-5 w-full '>
                    <div className='flex flex-col gap-y-0.5'>
                        <p className='text-xs sm:text-sm md:text-sm lg:text-sm xl:text-sm'>$25,000</p>
                        <p className='opacity-40 text-xs sm:text-sm md:text-sm lg:text-sm xl:text-sm'>4.5</p>
                    </div>
                    <div className='flex flex-col items-end gap-y-0.5'>
                        <p className='text-xs sm:text-sm md:text-sm lg:text-sm xl:text-sm text-red-500'>5d/3n</p>
                        <div className='px-1 py-1 bg-red-500 w-fit rounded-[5px]  '>
                            <p className='text-white text-xs font-medium'>55%off</p>
                        </div>
                    </div>
                </div>

                <div className='bg-gray-300/20 p-5 rounded-lg flex flex-wrap gap-5 justify-between'>
                    <div className='flex flex-col items-end w-fit'>
                        <div className='flex justify-between items-center gap-4'>
                            <img src="assets/images/svg/calendar.svg" alt="" />
                            <p className='opacity-25'>Check-in</p>
                        </div>
                        <p>May 15,2023</p>
                    </div>
                    <div className='flex flex-col items-end w-fit'>
                        <div className='flex justify-between items-center gap-4'>
                            <img src="assets/images/svg/calendar.svg" alt="" />
                            <p className='opacity-25'>Check-out</p>
                        </div>
                        <p>May 15,2023</p>
                    </div>
                    <div className='flex flex-col items-end w-fit'>
                        <div className='flex justify-between items-center gap-4'>
                            <img src="assets/images/svg/user.svg" alt="" />
                            <p className='opacity-25'>Guest</p>
                        </div>
                        <p>2 Guest</p>
                    </div>


                </div>
                    <p className='px-5 py-2 bg-red-500 capitalize w-fit text-white rounded-md'>reserve now</p>

            </div>

            <div className='w-full fixed bottom-0 left-0 bg-white MobileView-DesktopHide-block z-30 shadow-lg'>
                <div className='flex justify-between items-center p-4 '>     
                <div className='flex flex-col gap-5'>     
                <div className='flex gap-x-2'>
                    <p className='text-md'>25,000</p> 
                    <p className='text-red-500 text-sm'>5d/3n</p>
                </div>
               <p className='underline underline-offset-4'>10-15 mar</p>
                </div>

                <p className='px-5 py-2 bg-red-500 capitalize w-fit text-white rounded-md'>reserve now</p>
                </div>

                
            </div>
        </>
    )
}

export default DetailCard