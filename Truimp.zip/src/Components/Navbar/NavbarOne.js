import React, { useState } from 'react'
import { useNavigate } from 'react-router';
import LoginDesktopModal from '../../Modal/LoginDesktopModal';
import LoginMobileModal from '../../Modal/LoginMobileModal'


function NavbarOne() {
    const [activeMobileModal, setActiveMobileModal] = useState(false)
    const [activeMobileModalDesk, setActiveMobileModalDesk] = useState(false)


    const MobileModalHandler = () =>{
        setActiveMobileModal(!activeMobileModal);
    }
    const DesktopModalHandler = () =>{
        setActiveMobileModalDesk(!activeMobileModalDesk);
    }

    const navigate = useNavigate();

    const NavigationData = [
        {
            title: "",
            img: 'assets/images/svg/instagram.svg',
            link: "",
        },
        {
            title: "",
            img: 'assets/images/svg/email.svg',
            link: "",
        },
        {
            title: "",
            img: "assets/images/svg/whatsapp.svg",
            link: "",
        },
        {
            title: "9677033863",
            img: "assets/images/svg/phone.svg",
            link: "",
        },
        {
            title: "info@truimph.comholidays",
            img: "assets/images/svg/email.svg",
            link: "",
        },
    ]
    return (
        <>
            <div className='bg-white sm:bg-red-500 md:bg-red-500 lg:bg-red-500 xl:bg-red-500'>
                <div className='brand-container flex justify-between items-center'>
                    <img onClick={()=> navigate('/')} className='h-[60px] w-auto p-4 bg-white rounded-[5px] cursor-pointer' src="assets/images/logo.png" alt="" />
                    <ul className='  hidden sm:flex md:flex lg:flex xl:flex   items-center gap-x-3 text-white '>
                        {NavigationData.map((list, index) => (
                            <li key={index}>
                                <div className='flex gap-x-2 cursor-pointer'>
                                    <img className='w-5 h-auto' src={list.img} alt="" />
                                    <p className='hidden sm:hidden md:hidden lg:block xl:block '>{list.title}</p>
                                </div>
                            </li>
                        ))}
                    </ul>
                    <img onClick={MobileModalHandler} className='block sm:hidden md:hidden lg:hidden xl:hidden ' src="assets/images/svg/circle-user-black.svg" alt="" />
                </div>
            </div>
            <LoginMobileModal active={activeMobileModal} Handler={MobileModalHandler}/>
            <LoginDesktopModal active={activeMobileModalDesk} Handler={DesktopModalHandler} />
        </>

    )
}

export default NavbarOne