
import React, { useState } from 'react'

function Itenerary() {
    const [Expand, setExpand] = useState(false);
    return (
        <>
            <div className={Expand? 'flex flex-col p-5 transition-all duration-300 bg-white shadow-lg rounded-[10px]': 'flex flex-col rounded-[10px transition-all duration-300 p-5 bg-[#F7F7F7]'}>
                <div className='flex justify-between   rounded-[5px]'>
                    <div className='flex gap-x-5'>
                        <img className='w-[200px] h-[100px] object-cover rounded-[10px]' src="assets/images/grid1.png" alt="" />
                        <div className='flex flex-col justify-between'>
                            <h1>Day 1 : Arrival at singapore airport</h1>
                            <div className='flex gap-x-5 items-center'>
                                <img src="assets/images/svg/building.svg " alt="" />
                                <p className='text-sm'>stayed at luxury hotel</p>
                            </div>
                            <div className='flex gap-x-5 items-center'>
                                <img src="assets/images/svg/building.svg " alt="" />
                                <p className='text-sm'>stayed at luxury hotel</p>
                            </div>
                        </div>
                    </div>
                    <img onClick={()=>{setExpand(!Expand)}} className={Expand? ' transition-all duration-300  rotate-180 cursor-pointer':' transition-all duration-300 cursor-pointer'}  src="assets/images/svg/double-arrow.svg" alt="" />

                </div>
                <div className={Expand? 'block transition-all duration-300':'transition-all duration-300 hidden'}>     
                <div className='mt-5 flex flex-col gap-y-2'>
                    <div className='flex flex-col gap-y-2 '>
                        <div className='flex items-center gap-x-2'>
                            <div className='h-5 w-5 rounded-full bg-red-300 flex justify-center items-center'>
                                <div className='h-3 w-3 rounded-full bg-red-500'></div>
                            </div>
                            <p>stop 1; Hop-on Hop-off big bus sightseeing tour <span class='text-red-500'>(1hr)</span></p>
                        </div>
                        <div className='border border-dashed border-black h-0  w-5 rotate-90'></div>
                    </div>
                    <div className='flex flex-col gap-y-2 '>
                        <div className='flex items-center gap-x-2'>
                            <div className='h-5 w-5 rounded-full bg-red-300 flex justify-center items-center'>
                                <div className='h-3 w-3 rounded-full bg-red-500'></div>
                            </div>
                            <p>stop 1; Hop-on Hop-off big bus sightseeing tour <span class='text-red-500'>(1hr)</span></p>
                        </div>
                        <div className='border border-dashed border-black h-0  w-5 rotate-90'></div>
                    </div>
                    <div className='flex flex-col gap-y-2 '>
                        <div className='flex items-center gap-x-2'>
                            <div className='h-5 w-5 rounded-full bg-red-300 flex justify-center items-center'>
                                <div className='h-3 w-3 rounded-full bg-red-500'></div>
                            </div>
                            <p>stop 1; Hop-on Hop-off big bus sightseeing tour <span class='text-red-500'>(1hr)</span></p>
                        </div>
                        <div className='border border-dashed border-black h-0  w-5 rotate-90'></div>
                    </div>
                    <div className='flex flex-col gap-y-2 '>
                        <div className='flex items-center gap-x-2'>
                            <div className='h-5 w-5 rounded-full bg-red-300 flex justify-center items-center'>
                                <div className='h-3 w-3 rounded-full bg-red-500'></div>
                            </div>
                            <p>stop 1; Hop-on Hop-off big bus sightseeing tour <span class='text-red-500'>(1hr)</span></p>
                        </div>
                        <div className='border border-dashed border-black h-0  w-5 rotate-90'></div>
                    </div>
                    <div className='flex flex-col gap-y-2 '>
                        <div className='flex items-center gap-x-2'>
                            <div className='h-5 w-5 rounded-full bg-red-300 flex justify-center items-center'>
                                <div className='h-3 w-3 rounded-full bg-red-500'></div>
                            </div>
                            <p>stop 1; Hop-on Hop-off big bus sightseeing tour <span class='text-red-500'>(1hr)</span></p>
                        </div>
                        <div className='border border-dashed border-black h-0  w-5 rotate-90'></div>
                    </div>
                    <div className='flex flex-col gap-y-2 '>
                        <div className='flex items-center gap-x-2'>
                            <div className='h-5 w-5 rounded-full bg-red-300 flex justify-center items-center'>
                                <div className='h-3 w-3 rounded-full bg-red-500'></div>
                            </div>
                            <p>stop 1; Hop-on Hop-off big bus sightseeing tour <span class='text-red-500'>(1hr)</span></p>
                        </div>
                        <div className='border border-dashed border-black h-0  w-5 rotate-90 hidden'></div>
                    </div>
                </div>
                </div>
            </div>
        </>
    )
}

export default Itenerary