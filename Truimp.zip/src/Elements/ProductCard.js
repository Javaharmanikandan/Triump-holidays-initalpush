import React from 'react'
import { useNavigate } from 'react-router'

function ProductCard() {
    const navigate = useNavigate()
    return (
        <>
            <div onClick={()=> navigate('/detail')} className='flex cursor-pointer flex-col w-fit p-3 border border-black/10 rounded-[10px] relative mx-2 my-3'>
                <img className='object-cover h-[150px] sm:h-[200px] md:h-[300px] lg:h-[300px] xl:h-[300px] w-auto  rounded-[15px]' src="assets/images/prd1.png" alt="prd1" />
                <div className='flex flex-col gap-y-5 mt-3'>
                    <p className=' text-sm sm:text-md md:text-md lg:text-md xl:text-md'>Enjoy the beauty of the Singapore</p>
                    <div className='flex justify-between'>
                        <div className='flex flex-col gap-y-0.5'>
                            <p className='text-xs sm:text-sm md:text-sm lg:text-sm xl:text-sm'>Singapore</p>
                            <p className='opacity-40 text-xs sm:text-sm md:text-sm lg:text-sm xl:text-sm'>4.5</p>
                        </div>
                        <div className='flex items-end flex-col gap-y-0.5'>
                            <p className='text-xs sm:text-sm md:text-sm lg:text-sm xl:text-sm font-bold'>$25,000</p>
                            <p className='o text-xs sm:text-sm md:text-sm lg:text-sm xl:text-sm text-red-500'>4d/3n</p>
                        </div>
                    </div>
                </div>
                <div className='absolute top-4 right-4 bg-white p-2 rounded-full cursor-pointer'>
                    <img className='  h-[20px] w-[20px] ' src="assets/images/svg/bookmark.svg" alt="" />
                </div>
                <div className='px-1 py-1 bg-red-500 w-fit rounded-[5px] absolute -top-3 -right-3 '>
                    <p className='text-white text-xs font-medium'>55%off</p>
                </div>
            </div>
        </>
    )
}

export default ProductCard