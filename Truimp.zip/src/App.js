import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Footer from "./Components/Footer/Footer";
import NavbarOne from "./Components/Navbar/NavbarOne";
import NavbarTwo from "./Components/Navbar/NavbarTwo";
import Home from "./Pages/Home";
import HotelDetail from "./Pages/HotelDetail";
import Profile from "./Pages/Profile";
import Search from "./Pages/Search";
import ViewAllPhotos from "./Pages/ViewAllPhotos";
import "./Style/style.css";

function App() {
  return (
    <>
      <Router>
        <Routes>
          <Route path="/" element={<HeaderOne />} />
          <Route path="/*" element={<HeaderTwo />} />
        </Routes>
      </Router>

    </>
  );
}

const HeaderOne = () => {
  return (
    <>
      <NavbarOne />
      <Routes>
        <Route path="/" element={<Home />} />
      </Routes>
      <Footer />
    </>

  )
}

const HeaderTwo = () => {
  return (
    <>
      <NavbarTwo />
      <Routes>
        <Route path="/search" element={<Search />} />
        <Route path="/detail" element={<HotelDetail />} />
        <Route path="/photos" element={<ViewAllPhotos />} />
        <Route path="/profile" element={<Profile />} />

      </Routes>
      <Footer />
    </>
  )
}

export default App;
