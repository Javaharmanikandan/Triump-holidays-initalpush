import React, { useEffect } from 'react'
import Masonry, { ResponsiveMasonry } from "react-responsive-masonry"
import { ScrolltoTop } from '../Utility'

function ViewAllPhotos() {
    // Document title
    document.title = 'Truimp Holiday'

    useEffect(() => {
        ScrolltoTop()
    }, [])

    return (
        <>
            <div className='brand-container my-10'>
                <div className='  lg:mx-72 '>
                    <ResponsiveMasonry columnsCountBreakPoints={{ 350: 2, 750: 2, 900: 2 }} >
                        <Masonry gutter={"10px"}>
                            <img className='w-full h-full object-cover ' src="assets/images/prd1.png" alt="" />
                            <img className='w-full h-full object-cover ' src="assets/images/ddt2.png" alt="" />
                            <img className='w-full h-full object-cover ' src="assets/images/ddt3.png" alt="" />
                            <img className='w-full h-full object-cover ' src="assets/images/ddt4.png" alt="" />
                            <img className='w-full h-full object-cover ' src="assets/images/ddt5.png" alt="" />
                            <img className='w-full h-full object-cover ' src="assets/images/grid6.png" alt="" />
                            <img className='w-full h-full object-cover ' src="assets/images/ddt1.png" alt="" />
                            <img className='w-full h-full object-cover ' src="assets/images/ddt2.png" alt="" />
                            <img className='w-full h-full object-cover ' src="assets/images/grid6.png" alt="" />
                            <img className='w-full h-full object-cover ' src="assets/images/ddt3.png" alt="" />
                            <img className='w-full h-full object-cover ' src="assets/images/ddt4.png" alt="" />
                            <img className='w-full h-full object-cover ' src="assets/images/ddt5.png" alt="" />
                        </Masonry>
                    </ResponsiveMasonry>
                </div>
            </div>
        </>
    )
}

export default ViewAllPhotos