import React, { useEffect } from 'react'
import Itenerary from '../Elements/Itenerary'
import Masonry, { ResponsiveMasonry } from "react-responsive-masonry"
import TripFram from '../Elements/TripFram'
import { ScrolltoTop } from '../Utility'
import ProductCard from '../Elements/ProductCard'
import DetailCard from '../Components/HotelDetailcomponents/DetailCard'


function HotelDetail() {

  // Document title
  document.title = 'Truimp Holiday'

  useEffect(() => {
    ScrolltoTop()
  }, [])


  const ImageData = ["assets/images/ddt1.png", "assets/images/ddt2.png", "assets/images/ddt3.png", "assets/images/ddt4.png", "assets/images/ddt5.png", "assets/images/ddt6.png"]
  return (
    <>
      <div className='brand-container my-10'>
        <div className='mb-5'>
          <div className='hidden sm:hidden md:hidden lg:block xl:block'>
            <ResponsiveMasonry columnsCountBreakPoints={{ 350: 2, 750: 2, 900: 4 }} >
              <Masonry gutter={"10px"}>
                {/* {ImageData.map((item, index)=>

                )} */}
                <img className='w-full h-full object-cover ' src="assets/images/ddt1.png" alt="" />
                <img className='w-full h-full object-cover ' src="assets/images/ddt2.png" alt="" />
                <img className='w-full h-full object-cover ' src="assets/images/ddt3.png" alt="" />
                <img className='w-full h-full object-cover ' src="assets/images/ddt4.png" alt="" />
                <img className='w-full h-full object-cover ' src="assets/images/ddt5.png" alt="" />
                <div className='relative group'>
                  <img className='w-full h-full object-cover ' src="assets/images/grid6.png" alt="" />
                  <div className='hidden group-hover:block'>
                    <div className='absolute  items-center cursor-pointer flex gap-x-2 rounded-full bottom-0 right-0 py-2 px-3 m-2 bg-white/40 backdrop-blur-sm text-white'>
                      <img className='' src="assets/images/svg/window.svg" alt="" />
                      <p className='text-sm'>see all photo</p>
                    </div>
                  </div>
                </div>
              </Masonry>
            </ResponsiveMasonry>
          </div>
          <div className='relative block sm:block md:block lg:hidden xl:hidden'>
            <img className='w-full h-full object-cover ' src="assets/images/grid6.png" alt="" />
            <div className='absolute items-center cursor-pointer flex gap-x-2 rounded-full bottom-0 right-0 py-2 px-3 m-2 bg-white/40 backdrop-blur-sm text-white'>
              <img className='' src="assets/images/svg/window.svg" alt="" />
              <p className='text-sm'>see all photo</p>
            </div>
          </div>
        </div>


        <div className='flex flex-col sm:flex-row md:flex-row lg:flex-row xl:flex-row justify-between gap-x-3'>
          <div className='w-full sm:w-full md:w-2/3 lg:w-2/3 xl:2/3 '>
            <div className='flex justify-between gap-x-2'>
              <div className='flex flex-col items-start'>
                <p className='brand-title '>Singapore Holidays package</p>
                <div className='flex gap-x-2 items-center'>
                  <img className='h-4 w-auto opacity-40' src="assets/images/svg/location.svg" alt="" />
                  <p className='brand-sub-title opacity-40'>singapore</p>
                </div>
              </div>
              <div className='flex flex-col items-end'>
                <div className='flex gap-x-2 items-center justify-end'>
                  <img className='h-4 w-auto opacity-40' src="assets/images/svg/cal-time.svg" alt="" />
                  <p className='brand-sub-title opacity-40'>singapore</p>
                </div>
                <p className='text-red-500 brand-sub-title'>5d/3n</p>
              </div>
            </div>

            <p className='text-[#757575] text-sm sm:text-md my-5 lg:text-md xl:text-md w-full sm:w-2/3  md:w-3/5 lg:w-3/5 xl:w-3/5'>Lorem ipsum dolor sit amet consectetur. Turpis nunc elementum volutpat et vitae ut vitae. Ultricies congue vitae platea bibendum pellentesque neque praesent. Mauris laoreet elementum sed nunc massa. Pharetra diam id in mattis diam. A ipsum accumsan facilisi amet id quisque felis amet sollicitudin. Maecenas volutpat diam quis enim. Ullamcorper in sodales ornare elementum arcu placerat metus et id. Aliquam tortor sit purus adipiscing metus dictumst mauris posuere.</p>

            <div className='flex flex-col items-start gap-y-4'>
              <p className='brand-title'>Amenties</p>
              <div className='flex flex-wrap gap-3'>
                <div className='flex gap-x-2 items-center'>
                  <img src="assets/images/svg/building.svg" alt="" />
                  <p className='brand-sub-title opacity-50 whitespace-nowrap'>Stay in 3 star hotel</p>
                </div>
                <div className='flex gap-x-2 items-center'>
                  <img src="assets/images/svg/umb.svg" alt="" />
                  <p className='brand-sub-title opacity-50'>Beach view stay</p>
                </div>
                <div className='flex gap-x-2 items-center'>
                  <img src="assets/images/svg/umb.svg" alt="" />
                  <p className='brand-sub-title opacity-50'>Beach view stay</p>
                </div>
              </div>
              <div className='flex flex-wrap gap-3'>
                <div className='flex gap-x-2 items-center'>
                  <img src="assets/images/svg/building.svg" alt="" />
                  <p className='brand-sub-title opacity-50 whitespace-nowrap'>Kids playing area</p>
                </div>
                <div className='flex gap-x-2 items-center'>
                  <img src="assets/images/svg/umb.svg" alt="" />
                  <p className='brand-sub-title opacity-50 whitespace-nowrap'>Multi cusine</p>
                </div>
                <div className='flex gap-x-2 items-center'>
                  <img src="assets/images/svg/umb.svg" alt="" />
                  <p className='brand-sub-title opacity-50 whitespace-nowrap'>Multi cusine</p>
                </div>
              </div>
            </div>

            <div className='flex flex-col gap-y-2'>
              <Itenerary />
              <Itenerary />
              <Itenerary />
              <Itenerary />
            </div>
          </div>

          <div className='w-full sm:w-2/6 md:w-2/6 lg:w-2/6 xl:w-2/6 mx-2'>
            <div className='w-full border rounded-lg px-2 py-4 flex justify-between items-center'>
              <img src="assets/images/svg/left-solid-arrow.svg" alt="" />
              <div className='flex flex-col justify-between items-center gap-5'>
                <p>The trip arranged by triumph <br />
                  holidays was best in my life</p>
                <div className='flex gap-x-2 items-center'>
                  <img className='w-7 h-7 rounded-full object-cover' src="assets/images/ddt5.png" alt="" />
                  <p>content</p>
                </div>
              </div>
            </div>
             <DetailCard />
            <div className='w-full p-5'>
              <div className=''>
                <img className='w-full h-auto ' src="assets/images/mb-word.png" alt="" />

              </div>
            </div>
          </div>
        </div>

        <div className='my-5'>
          <p className='brand-title my-2'>Our best  <span className='text-red-500'>family and couple package</span></p>
          <div className='grid grid-cols-2 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4'>
            <ProductCard />
            <ProductCard />
            <ProductCard />
            <ProductCard />

          </div>
        </div>
        <div className='my-5'>
          <p className='brand-title my-2'>Other Singapore You may <span className='text-red-500'>Like</span></p>
          <div className='grid grid-cols-2 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4'>
            <ProductCard />
            <ProductCard />
            <ProductCard />
            <ProductCard />

          </div>
        </div>

      </div>
    </>
  )
}

export default HotelDetail