import React, { useEffect } from 'react'
import BottomMenu from '../Components/HomeComponents/BottomMenu'
import ChoosebyTheme from '../Components/HomeComponents/ChoosebyTheme'
import FrequentlyAskQuestion from '../Components/HomeComponents/FrequentlyAskQuestion'
import HeaderSection from '../Components/HomeComponents/HeaderSection'
import MobileSearchSection from '../Components/HomeComponents/MobileSearchSection'
import SectionBanner from '../Components/HomeComponents/SectionBanner'
import Sliders from '../Components/HomeComponents/Slidercus'
import ProductCard from '../Elements/ProductCard'
import { ScrolltoTop } from '../Utility'

function Home() {

    // Document title
    document.title = 'Truimp Holiday'

    useEffect(() => {
        ScrolltoTop()
    }, [])


    return (
        <>
            <HeaderSection />
            <MobileSearchSection />
            <Sliders title={"domestic "} />
            <SectionBanner />
            <ChoosebyTheme />
            <Sliders title={"international "} />
            <div>
          <p className='text-2xl my-2 text-center font-bold capitalize'>Don’t take our <span className='text-red-500'>words</span> for it</p>

                <img className='w-full h-auto MobileHide-DesktopView-block' src="assets/images/svg/word.svg" alt="" />
                <img className='w-full h-auto MobileView-DesktopHide-block' src="assets/images/mb-word.png" alt="" />
            </div>
            <FrequentlyAskQuestion />
            <BottomMenu />

            
        </>

    )
}

export default Home